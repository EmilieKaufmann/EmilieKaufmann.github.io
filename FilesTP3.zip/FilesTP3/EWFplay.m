function [Actions,Rewards]=EWFplay(n,G,eta,Seq)

[nA,~]=size(G);

Actions=zeros(1,n);
Rewards=zeros(1,n);

w=ones(1,nA);

for i=1:n
    % A plays
    p=w/sum(w);
    actionA=simu(p);
    Actions(i)=actionA;
    % A recieves reward
    actionB=Seq(i);
    Rewards(i)=G(actionA,actionB);
    % A updates weights    
    rewards=(G(:,actionB))';
    w=w.*exp(eta*rewards);
end




