function [X,R] = trajectory(n,x0,pi,M,K,h,c,p,D)
% n: length of the trajectory
% x0: initial state
% pi: policy
% X: sequence of sucessive states
% R: sequence of sucessive rewards  


    

end

