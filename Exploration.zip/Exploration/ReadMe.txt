You can use all the same instructions as last time and you need to add the following things in your virtual environement: 

pip install gym[all] 
