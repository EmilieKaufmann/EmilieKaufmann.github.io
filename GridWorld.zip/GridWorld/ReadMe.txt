You need to install the RL berry library. I recommend doing so in a dedicated conda environement. 

# creating a conda environment for the TP and activating it 

conda create -n TP3 python=3.8
conda activate TP3

# install what will be needed

pip install jupyterlab 

pip install git+https://github.com/rlberry-py/rlberry.git@mva2021#egg=rlberry[default]

[videos stuff]
pip install ffmpeg-python  
pip install pyvirtualdisplay 
apt-get install -y xvfb python-opengl ffmpeg  

# create a repository for videos inside the repository in which you will run the notebook 

mkdir videos

# then you are all set to start the notebook, running the usual "jupyter notebook" command 


